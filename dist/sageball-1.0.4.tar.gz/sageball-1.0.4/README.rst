Sageball
========

Sageball is an extension of SageMath with additional functionalities.

It should be imported in a sagemath script.

Author: pikaball (whitesworder@gmail.com)

Currently Implemented Functionalities:
---------------------------------------
- hensel_solve(f,p,r): solve polynomial roots on GF(p^r)